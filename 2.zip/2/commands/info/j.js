const discord = require("discord.js")
const config = require("../../config.js")
const db = require("quick.db")

module.exports = {
        name: "snipe",
        description: "Obtenir le dernier msg supprimer",
        usage: "snipe",
        category: "util",
        run: async(client, message, args) => {
            let prefix = await db.fetch(`prefix_${message.guild.id}`)
            if (prefix == null) {
                prefix = config.DEFAULT_PREFIX
            }
            let color = db.fetch(`config_couleur_${message.guild.id}`)

            run: async(bot, message, args) => {



                const msg = bot.snipes.get(message.channel.id)
                if (!msg) return message.channel.send("there is no deleted messages")
                const embed = new discord.MessageEmbed()
                    .setAuthor(msg.author, message.author.displayAvatarURL({ dynamic: true }))
                    .setDescription(`**Message Supprimer:** ${msg.content}`)
                    .setColor(color)
                    .setTimestamp()
                if (msg.image) embed.setImage(msg.image)
                message.channel.send(embed)
            }
        };,