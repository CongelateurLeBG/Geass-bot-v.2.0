const { MessageEmbed } = require("discord.js");
const discord = require("discord.js");
const db = require("quick.db")
const { default_prefix } = require("../../config.json")
const config = require("../../config.json")


module.exports = {
    name: "vc",
    description: "Obtenir le nombre de personne en voc",
    usage: "help <commande>",
    category: "util",
    run: async(client, message, args) => {
        let prefix = await db.fetch(`prefix_${message.guild.id}`)
        if (prefix == null) {
            prefix = config.DEFAULT_PREFIX
        }

        let color = db.fetch(`config_couleur_${message.guild.id}`)
        const voiceChannels = message.guild.channels.cache.filter(c => c.type === 'voice');


        let count = 0;
        let counter = 0;
        for (const [id, voiceChannel] of voiceChannels) count += voiceChannel.members.size;
        let Embed = new discord.MessageEmbed()
            .setTitle("🎙 __Salons vocaux__")
            .setDescription("Il y a actuellement 🔊 **" + count + " ** personnes en vocal sur le serveur.")
            .setColor(color)
            .setFooter(`${client.user.username}`)
            .setTimestamp()
        message.channel.send(Embed)

    },

}