const Discord = require("discord.js");
const db = require("quick.db")

module.exports = {
      name: 'embed',
  category: "mod",
  usage: "embed",
  description: "menu intéractif d'embed",
  run: async (client, message, args) => {
  },
  run: async (client, message, args) => {
 
    if (!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send("**vous n'avez pas la Permissions  - [ADMINISTRATOR]**");
    if (!message.guild.me.hasPermission("ADMINISTRATOR")) return message.channel.send("**vous n'avez pas la  Permissions - [ADMINISTRATOR]**");

        let msg = await message.channel.send("• *Veuillez attendre que les réactions aient fini d'être ajouter .*")
 
        await msg.react('🖊️')
        await msg.react('💬')
        await msg.react('🕵️')
        await msg.react('🔻')
        await msg.react('🔳')
        await msg.react('🖼️')
        await msg.react('🌐')
        await msg.react('🎨')
        await msg.react('⏲')
        await msg.react('➕')
        await msg.react('❌')
        await msg.react('✅').then(async (m) => {
 
     const msg111 = new Discord.MessageEmbed()
    .setTitle("Embed Creation Menu :")
    .addField(`\`🖊️\``, "• *Permet de modifier le titre de  l'embed*", true)
    .addField(`\`💬\``, "• *Vous permet de modifier la description de l'embed*", true)
    .addField(`\`🕵️\``, "• *Permet de modifier l'auteur de  l'Embed*", true)
    .addField(`\`🔻\``, "• *permet de modifier le footer de l'embed*", true)
    .addField(`\`🔳\``, "• *permmet de modifier le thumbail de l'Embed*", true)
    .addField(`\`🖼️\``, "• *Permet de modifier l'image de l'embed*", true)
    .addField(`\`🌐\``, "• *permet des modifier l'url de l'embed*", true)
    .addField(`\`🎨\``, "• *permet de modifier*", true)
    .addField(`\`⏲\``, "• *Permet d'ajouter un timestamps a l'embed*", true)
    .addField(`\`➕\``, "• *Parmet d'ajoute un field*", true)
    .addField(`\`❌\``, "• *Permet de finir la construction de l'embed *", true)
    .addField(`\`✅\``, "• *Permet d'envoyer l'embed*", true)
    .setColor("000000")
    .setFooter("Geass- Antiraid | Embed Creation Menu")
msg.edit(" ", msg111)
    const embedbase = new Discord.MessageEmbed()
    .setDescription ("** **")
 
           let msgg = await message.channel.send(embedbase)

            let collector = msg.createReactionCollector((reaction, user) => user.id === message.author.id);
            collector.on("collect", async (reaction, user) => {
                if (reaction._emoji.name === "🖊️") {
                    let question = await message.channel.send("Quelle est votre titre? (\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération a été annulée !").then((mm) => mm.delete({ timeout: 5000 })) }
collected.first().delete()
                        question.delete()
                        embedbase.setTitle(collected.first().content)
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé mais je ne peux pas modifier le titre  !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }

                if (reaction._emoji.name === "💬") {
                    let question = await message.channel.send("Quelle est votre description ?(\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("l'opération a été annulée !").then((mm) => mm.delete({ timeout: 5000 })) }
            
                        collected.first().delete()
                        question.delete()
                        embedbase.setDescription(collected.first().content)
msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                                message.channel.send("**Désolé je ne peut pas changer la description !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }
    
                if (reaction._emoji.name === "🕵️") {
                    const embedquest = new Discord.MessageEmbed()
                    let question = await message.channel.send("Quelle est votre auteur ?(\ `cancel \` to cancel)", embedquest.setDescription("Vous pouvez mentionner un utilisateur pour mettre son pseudo et sa photo de profil "))
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération à été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
                            collected.first().delete()
                            question.delete()
                            if (collected.first().mentions.users.size <= 0)
                            {
                                auteur = collected.first().content;
                                const question2 = await message.channel.send("Voulez-vous ajouter une image à l'auteur, sinon entrez  `non`");
                                const auteurImg = (await message.channel.awaitMessages(filter, { max: 1, time: 60000, errors: ['time']})).first();
question2.delete();
                                auteurImg.delete();
                                const img = auteurImg.content
                                const liens = [
                                    "https://",
                                    "http://",
                                    "https",
                                    "http"
                                ];
                                if (!liens.some(word => img.includes(word))){
                                    embedbase.setAuthor(auteur)
                                    message.channel.send("Vous avez choisi de ne pas ajouter d'image ou le lien n'est pas valide ").then((mm) => mm.delete({ timeout: 5000 })) }

                                    if (liens.some(word => img.includes(word))){
                                embedbase.setAuthor(auteur, auteurImg.content)
                                    }
                            }
                            if (collected.first().mentions.users.size > 0) 
                            {
                                auteur = collected.first().mentions.users.first();
         
                                embedbase.setAuthor(auteur.username, auteur.displayAvatarURL({dynamic: true}));
                            }
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé mais je ne peux pas modifier l'auteur  !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }
                
                if (reaction._emoji.name === "🔻") {
                    const embedquest = new Discord.MessageEmbed()
                    let question = await message.channel.send("Quelle est votre footer ?(\ `cancel \` to cancel")
embedquest.setDescription("Vous pouvez mentionner un utilisateur pour mettre son pseudo et sa photo de profil ")
const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération à été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
                            collected.first().delete()
                            question.delete()
                            if (collected.first().mentions.users.size <= 0)
                            {
                                footer = collected.first().content;
                                const question2 = await message.channel.send("Voulez-vous ajouter une image au footer, sinon entrez  `non`");
                                const footerImg = (await message.channel.awaitMessages(filter, { max: 1, time: 60000, errors: ['time']})).first();
                                question2.delete();
                                footerImg.delete();
                                const img = footerImg.content
                                const liens = [
                                    "https://",
                                    "http://",
                                    "https",
                                    "http"
                                ];
                                if (!liens.some(word => img.includes(word))){
                                    embedbase.setFooter(footer)
                                    message.channel.send("Vous avez choisi de ne pas ajouter d'image ou le lien n'est pas valide ").then((mm) => mm.delete({ timeout: 5000 })) }

                                    if (liens.some(word => img.includes(word))){
                                embedbase.setFooter(footer, footerImg.content)
                                    }
                            }
if (collected.first().mentions.users.size > 0) 
                            {
                                footer = collected.first().mentions.users.first();
         
                                embedbase.setFooter(footer.username, footer.displayAvatarURL({dynamic: true}));
                            }
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé je ne pas modifier le footer !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }

                if (reaction._emoji.name === "🔳") {
                    let question = await message.channel.send("Quelle est votre miniature ?(\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération à été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
                        const thumbnail = collected.first().content
                        const liens = [
                            "https://",
                            "http://",
                            "https",
                            "http"
                        ];
                        if (!liens.some(word => thumbnail.includes(word))){
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération a été annulée, vous devez spécifier un lien !").then((mm) => mm.delete({ timeout: 5000 })) }
                       

                        collected.first().delete()
                        question.delete()
                        embedbase.setThumbnail(collected.first().content)
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Je ne peut pas modifier la Miniature !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }
if (reaction._emoji.name === "🖼️") {
                    let question = await message.channel.send("Quelle est votre image ?(\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération est annulé").then((mm) => mm.delete({ timeout: 5000 })) }
                            const image = collected.first().content
                            const liens = [
                                "https://",
                                "http://",
                                "https",
                                "http"
                            ];
                            if (!liens.some(word => image.includes(word))){
                                collected.first().delete()
                                question.delete()
                                return message.channel.send("L'opération a été annulée, vous devez spécifier un lien !").then((mm) => mm.delete({ timeout: 5000 })) }
collected.first().delete()
                        question.delete()
                        embedbase.setImage(collected.first().content, {size: 4096})
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé je ne peut pas modifier l'Image !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }

                if (reaction._emoji.name === "🌐") {
                    let question = await message.channel.send("Quelle est votre URL ?(\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération a été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
                            const url = collected.first().content
                            const liens = [
                                "https://",
                                "http://",
                                "https",
                                "http"
                            ];
                            if (!liens.some(word => url.includes(word))){
                                collected.first().delete()
                                question.delete()
                                return message.channel.send("L'opération a été annulée, vous devez spécifier un lien !").then((mm) => mm.delete({ timeout: 5000 })) }
                           
                                
                        collected.first().delete()
                        question.delete()
                        embedbase.setURL(collected.first().content)
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé je ne peut pas modifier l' URL !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }

                if (reaction._emoji.name === "🎨") {
                    let question = await message.channel.send("Quelle est votre couleure ?(\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = 
collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération à été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
            
                        collected.first().delete()
                        question.delete()
                        embedbase.setColor(collected.first().content)
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé je ne peut pas modifier la Couleur !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }
                if (reaction._emoji.name === "⏲") {

                        embedbase.setTimestamp()
                        msgg.edit(embedbase).catch(async (err) => {
 console.log(err)
                            message.channel.send("**Désole je ne peut pas modifier le Timestamp !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                      })
                }

                if (reaction._emoji.name === "➕") {
                    let question = await message.channel.send("Quelle est le titre de votre field Field ?(\ `cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération a été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
                        collected.first().delete()
                        question.delete()
                        titleField = collected.first().content
                        const question2 =
await message.channel.send('quelle est la description de votre field Field ?(\ `cancel \` to cancel)');
                        const descField = (await message.channel.awaitMessages(filter, { max: 1, time: 60000, errors: ['time']})).first()
                        const lowcase = descField.content.toLowerCase()
                        if (lowcase === "cancel") {
                            descField.delete() 
                            question2.delete()
                            return message.channel.send("L'opération a été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
                        
                        descField.delete()
                        question2.delete()
                        embedbase.addField(titleField, descField.content);
                        msgg.edit(embedbase)
                        }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé mais je ne peux pas ajouter de Field !**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }

                if (reaction._emoji.name === "✅") {
                    let question = await message.channel.send("Dans quelle  **Channel** j'envoie l'embed? (\ `Cancel \` to cancel)")
                    const filter = m => message.author.id === m.author.id;
                    message.channel.awaitMessages(filter, {
                        max: 1,
                        time: 60000,
                        errors: ['time']
                    }).then(async (collected) => {
                        const lowercase = collected.first().content.toLowerCase()
                        if (lowercase === "cancel") {
                            collected.first().delete()
                            question.delete()
                            return message.channel.send("L'opération a  été annulé!").then((mm) => mm.delete({ timeout: 5000 })) }
            
                        collected.first().delete()
                        question.delete()
                        let collect = collected.first()
                        let channel = collect.mentions.channels.first() || message.guild.channels.cache.get(collected.first().content)
                        if(channel == undefined){
                            return message.channel.send("L'opération a été annulée, le salon spécifié n'existe pas !").then((mm) => mm.delete({ timeout: 5000 })) }
                        
                        await channel.send(embedbase)

                    }).catch(async (err) => {
                            console.log(err)
                            message.channel.send("**Désolé j n'ait pas pu envoyez l'embed!**").then((mm) => mm.delete({
                                timeout: 5000
                        }));
                    })
                }

                if (reaction._emoji.name === "❌") {
                    collector.stop()
                    msg.delete()
                    msgg.delete()
                    return;
                }
                await reaction.users.remove(message.author.id);
            })
        });
    }
}
