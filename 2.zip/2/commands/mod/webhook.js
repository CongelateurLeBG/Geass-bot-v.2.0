const { MessageEmbed } = require("discord.js");
const discord = require("discord.js");
const { default_prefix } = require("../../config.json")
const config = require("../../config.json")
const db = require("quick.db")
module.exports = {
    name: "help",
    description: "Obtenir le nombre de webhok et de les supp",
    usage: "webhhook del/size",
    category: "mod",
    run: async(client, message, args) => {
        let prefix = await db.fetch(`prefix_${message.guild.id}`)
        if (prefix == null) {
            prefix = config.DEFAULT_PREFIX
        }





        if (!message.member.hasPermission('MANAGE_WEBHOOKS')) return message.channel.send("✖ \`ERREUR\` Vous n'avez pas la permission requise \`MANAGE_WEBHOOKS\`")
        const del = args[0] == 'delete';
        const size = args[0] == "size";
        if (size) {
            message.channel.fetchWebhooks().then((webhooks) => {
                message.channel.send('📈 Le serveur **' + message.guild.name + '** contient **' + webhooks.size + '** webhook.')
            })
        } else if (del) {
            message.channel.send('💃 Tout les webhook on été supprimé.')
            message.channel.fetchWebhooks().then((webhooks) => {
                webhooks.forEach((wh) => wh.delete());
            })
        }
    }
}