onst checkPermissionRole = (role) => role.permissions.has('ADMINISTRATOR') || role.permissions.has('KICK_MEMBERS') || role.permissions.has('BAN_MEMBERS') || role.permissions.has('MANAGE_GUILD') || role.permissions.has('MANAGE_CHANNELS');
const { MessageEmbed } = require("discord.js");
const discord = require("discord.js");
const db = require("quick.db")
const { default_prefix } = require("../../config.json")
const config = require("../../config.json")

module.exports = {
    name: "role",
    description: "ajouter ou supprimer un rôle à un gars",
    usage: "role add/remove  <un membre>",
    category: "mod",
    run: async(client, message, args) => {
        let prefix = await db.fetch(`prefix_${message.guild.id}`)
        if (prefix == null) {
            prefix = config.DEFAULT_PREFIX
        }
        let color = db.fetch(`config_couleur_${message.guild.id}`)

        const add = args[0] == 'add';
        const remove = args[0] == 'remove';
        if (!message.member.hasPermission('MANAGE_ROLES')) return message.channel.send("✖ \`ERREUR\` Vous n'avez pas la permission requise \`MANAGER_ROLES\`");
        let member = message.mentions.members.first() || message.guild.members.cache.get(args[1]);
        let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2]);
        if (role == undefined) return message.channel.send("Le rôle spécifié n'existe pas.")
        if (role.comparePositionTo(message.member.roles.highest) >= 0) return message.reply(`Vous ne pouvez pas ajouter le rôle ${role} à ${member} car vos permissions plus basse que ce rôle`)
        if (add && !member) return message.channel.send("Vous devez specifier un membre à ajouter le rôle")
        if (add && member && !role) return message.channel.send(`Vous devez specifier un rôle à ajouter à ${membre}`)
        if (member.user.id == message.author.id) return message.channel.send(`Vous ne pouvez pas vous ajoutez vous même le rôle (${role})`)
        if (!args[0]) {
            const hEmbed = new Discord.MessageEmbed()
                .setTitle(`Geass > onef`)
                .setDescription(`Example ect`)
                .setFooter(`fdf`)
                .setColor(color)
                .setTimestamp();
            return message.channel.send(hEmbed)
        } else if (add) {
            if (member.roles.cache.has(role.id)) return message.channel.send(`${member} possède déjà le rôle ${role}.`)
            member.roles.add(role).then(() => {
                message.channel.send(`J'ai ajouté le rôle (${role}) à ${member}`)
            }).catch((err) => {
                console.log(err)
                message.channel.send(`Il y a eu une erreur je n'ai pas pu enlever le rôle à ${member}`)
            })
        } else if (remove) {
            if (!member.roles.cache.has(role.id)) return message.channel.send(`${member} ne possède pas le rôle ${role}.`)
            member.roles.remove(role).then(() => {
                message.channel.send(`J'ai enlevé le rôle (${role}) à ${member}`)
            }).catch((err) => {
                console.log(err)
                message.channel.send(`Il y a eu une erreur je n'ai pas pu enlever le rôle à ${member}`)
            })
        }
    }
}