const { MessageEmbed } = require("discord.js");
const Discord = require("discord.js");
const db = require("quick.db")
const { default_prefix } = require("../../config.json")
const config = require("../../config.json")
const pagination = require('discord.js-pagination');
module.exports = {
    name: "lock",
    description: "Obtenir toutes les commandes du bot",
    usage: "help <commande>",
    category: "info",
    run: async(client, message, args) => {
        let prefix = await db.fetch(`prefix_${message.guild.id}`)
        if (prefix == null) {
            prefix = config.DEFAULT_PREFIX
        }

        let color = db.fetch(`config_couleur_${message.guild.id}`)


        if(!message.member.hasPermission('MANAGE_CHANNELS')) return message.channel.send("<a:9549_check_no:840643552786382848>   \`ERREUR\` Palaperm XD \`(ta besoin de la perm MANAGE_CHANNELS)\`")
        const lockAllOn = args[0] == 'all' && args[1] == "on";
        const lockAllOff =  args[0] == 'all' && args[1] == "off";
        const on = args[0] == 'on';
        const off = args[0] == 'off';
       

        const channels = message.guild.channels.cache.filter(ch => ch.type != 'category')
        const ch = message.channel
        
        if(!args[0]){
            const hEmbed = new Discord.MessageEmbed()
                .setAuthor(`Informations lock`)
                .setDescription(`[\`lock on\`](https://discord.gg/q2WhXYWfBX), [\`lock off\`](https://discord.gg/q2WhXYWfBX), [\`lock all on\`](https://discord.gg/q2WhXYWfBX), [\`lock all off\`](https://discord.gg/q2WhXYWfBX)`)
                .setFooter(`Informations lock`)
                .setColor(color)
                .setTimestamp();
            return message.channel.send(hEmbed)
        }
        
        if(lockAllOn){
            channels.forEach(channel =>{
                channel.updateOverwrite(message.guild.roles.everyone,{
                    SEND_MESSAGES : false
                })

            })
            message.channel.send("<a:5173_check_yes:840643500059525120>    Tout les salons on été fermé.")


          
        }else if(lockAllOff){
            channels.forEach(channel =>{
                channel.updateOverwrite(message.guild.roles.everyone,{
                    SEND_MESSAGES : true
                })

            })
            message.channel.send("<a:5173_check_yes:840643500059525120>  Tout les salons on été ouvert.")

        }else if(on){
            console.log(message.guild.channels.cache)
            ch.updateOverwrite(message.guild.roles.everyone,{
                SEND_MESSAGES : false
            }).then(() =>{
                message.channel.send("<a:5173_check_yes:840643500059525120>  Le salon a été fermé.")
            })
        }else if(off){
            ch.updateOverwrite(message.guild.roles.everyone,{
                SEND_MESSAGES : true
            }).then(() =>{
                message.channel.send("<a:5173_check_yes:840643500059525120>  Le salon a été ouvert.")
            })
        }
    }
}
